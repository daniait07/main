#ifndef UNTITLED_RATIONAL_H
#define UNTITLED_RATIONAL_H
#endif //UNTITLED_RATIONAL_H
#include <iosfwd>

class rational{
public:
    rational() = default;
    explicit rational(const int rhs);
    rational(const rational& rhs);
    rational(const int num, const int denum);
    rational& operator=(const rational& rhs) = default;
    ~rational() = default;

    bool operator==(const rational& rhs) const;
    bool operator!=(const rational& rhs) const;
    bool operator>(const rational& rhs) const;
    bool operator<(const rational& rhs) const;

    rational& operator+=(const rational& rhs);
    rational& operator+=(const int rhs){
        return operator+= (rational(rhs));
    }

    rational& operator-=(const rational& rhs);
    rational& operator-=(const int rhs){
        return operator-= (rational(rhs));
    }

    rational& operator*= (const rational& rhs);
    rational& operator*= (const int rhs){
        return operator*= (rational(rhs));
    }

    rational& operator/= (const rational& rhs);
    rational& operator/= (const int rhs){
        return operator/= (rational(rhs));
    }

    std::ostream& writeTo (std::ostream& ostrm) const;
    std::istream& readFrom (std::istream& istrm);

private:
    int num_{0};
    int denum_{1};
    int NOD(int a, int b);
    static const char slash{'/'};
    rational& round();
};
inline rational operator+ (const rational& lhs, const rational& rhs){
    return rational(lhs) += rhs;
}
inline rational operator+ (const rational& lhs, const int rhs){
    return rational(lhs) + rational(rhs);
}
inline rational operator+ (const int lhs, const rational& rhs){
    return rational(lhs) + rational(rhs);
}

inline rational operator- (const rational& lhs, const rational& rhs){
    return rational(lhs) -= rhs;
}
inline rational operator- (const rational& lhs, const int rhs){
    return rational(lhs) - rational(rhs);
}
inline rational operator- (const int lhs, const rational& rhs){
    return rational(lhs) - rational(rhs);
}

inline rational operator* (const rational& lhs, const rational& rhs){
    return rational(lhs) *= rhs;
}
inline rational operator* (const rational& lhs, const int rhs){
    return rational(lhs) * rational(rhs);
}
inline rational operator* (const int lhs, const rational& rhs){
    return rational(lhs) * rational(rhs);
}

inline rational operator/ (const rational& lhs, const rational& rhs){
    return rational(lhs) /= rhs;
}
inline rational operator/ (const rational& lhs, const int rhs){
    return rational(lhs) / rational(rhs);
}
inline rational operator/ (const int lhs, const rational& rhs){
    return rational(lhs) / rational(rhs);
}

std::ostream& operator<< (std::ostream& ostrm, const rational& rhs);
std::istream& operator>> (std::istream& istrm, rational& rhs);