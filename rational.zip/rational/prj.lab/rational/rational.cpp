#include <rational/rational.hpp>
#include <iostream>
#include <stdexcept>
#include <algorithm>

int rational::NOD(int a, int b){
    a = abs(a);
    b = abs(b);
    if (a == b || a == 0){
        return b;
    }
    if (a > b){
        return NOD(a-b, b);
    }
    return NOD(a, b-a);
}

rational& rational::round(){
    if (denum_ < 0){
        num_*=-1;
        denum_*=-1;
    }
    int nod = rational::NOD(num_,denum_);
    num_ /= nod;
    denum_ /= nod;
    return *this;
}
bool rational::operator==(const rational& rhs) const{
    return (num_ == rhs.num_ && denum_ == rhs.denum_);
}

bool rational::operator!=(const rational& rhs) const{
    return !operator==(rhs);
}

rational::rational (const int num, const int denum) {
    if (denum == 0)
        throw std::invalid_argument("Creating rational with 0 denum");
    num_ = num;
    denum_ = denum;
    this->round();
}
rational::rational(const int rhs)
{
    num_ = rhs;
    denum_ = 1;
    this->round();
}

rational::rational(const rational& rhs)
{
    num_ = rhs.num_;
    denum_ = rhs.denum_;
    this->round();
}

bool rational::operator>(const rational& rhs) const{
    if(num_*rhs.num_ < 0){
        return num_ > 0;
    }
    return num_*rhs.denum_ > rhs.num_*denum_;
}

bool rational::operator<(const rational& rhs) const{
    if(num_*rhs.num_ < 0){
        return num_ < 0;
    }
    return num_*rhs.denum_ < rhs.num_*denum_;
}

rational& rational::operator+=(const rational& rhs){
    int nod = NOD(num_,rhs.denum_);
    num_ = (num_*rhs.denum_)/nod + rhs.num_*denum_/nod;
    denum_ = (denum_*rhs.denum_)/nod;
    this->round();
    return *this;
}

rational& rational::operator-=(const rational& rhs){
    int nod = NOD(num_,rhs.denum_);
    num_ = (num_*rhs.denum_)/nod - rhs.num_*denum_/nod;
    denum_ = (denum_*rhs.denum_)/nod;
    this->round();
    return *this;
}

rational& rational::operator*= (const rational& rhs){
    num_ *= rhs.num_;
    denum_ *= rhs.denum_;
    this->round();
    return *this;
}

rational& rational::operator/= (const rational& rhs){
    denum_ *= rhs.num_;
    if (denum_ == 0 || rhs.denum_ == 0){
        throw std::invalid_argument("division by zero");
    }
    num_ *= rhs.denum_;
    this->round();
    return *this;
}

std::ostream& operator<< (std::ostream& ostrm, const rational& rhs)
{
    return rhs.writeTo(ostrm);
}
std::istream& operator>> (std::istream& istrm, rational& rhs)
{
    return rhs.readFrom(istrm);
}
std::ostream& rational::writeTo(std::ostream& ostrm) const
{
    ostrm << num_ << slash << denum_;
    return ostrm;
}
std::istream& rational::readFrom(std::istream& istrm)
{
    int num1(0);
    char slash(0);
    int denum1(1);
    istrm >> num1;
    istrm.get(slash);
    int trash = istrm.peek();
    istrm >> denum1;
    if (!istrm || trash > '9' || trash < '0') {
        istrm.setstate(std::ios_base::failbit);
        return istrm;
    }
    if (istrm.good() || istrm.eof()) {
        if (rational::slash == slash && denum1 > 0) {
            *this = rational(num1, denum1);
        }
        else {
            istrm.setstate(std::ios_base::failbit);
        }
    }
    return istrm;
}